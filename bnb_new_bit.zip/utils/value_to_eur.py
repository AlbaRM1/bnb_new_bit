import json
import re
import httpx

async def convert_to_eur(value, symbol_name, rate=False):    
    total_raw = str(value).replace('\xa0', '')
    print(total_raw)
    
    total = value

    if type(value) == str:
        if ',' in total_raw:
            total_raw = total_raw.replace(',', '')

        total = re.findall(r'[\d\.\d]+', total_raw)
        if total[0] == '.':
            total = total[1]
        else:
            total = total[0]
        symbol = total_raw.replace(total, '')
        print(symbol)
        
        total = total.strip()    
        total = round(float(total), 2)
    
    if rate:
        total = total * float(rate)
        total = round(total, 2)
        
        return [total, rate]
    else:
        async with httpx.AsyncClient(timeout=60) as client:
            response_json = await client.get(f'https://open.er-api.com/v6/latest/{symbol_name}')
            response_json = response_json.json()
            
            rate = response_json['rates']['EUR']

            total = total * float(rate)
            total = round(total, 2)
            
        return [total, rate]