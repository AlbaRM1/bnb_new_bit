from aiogram import types

def get_clear_statistic_kb():
    buttons = [
    ]
    
    
        
    keyboard = types.InlineKeyboardMarkup(inline_keyboard=buttons)
    return keyboard